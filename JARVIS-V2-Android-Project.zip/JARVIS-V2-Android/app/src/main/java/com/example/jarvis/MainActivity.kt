package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val requestSpeech = 101
    private val requestAudio = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(0xFF071426.toInt())
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S  V2"
            textSize = 30f
            setTextColor(0xFF42C8FF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "नमस्कार! म JARVIS हुँ।"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 28, 8, 28)
        }
        val listen = makeButton("🎙 बोल्नुहोस्") { startListening() }
        val camera = makeButton("📷 Camera खोल्नुहोस्") { openCamera() }
        val wifi = makeButton("Wi-Fi Settings") { openSettings("android.settings.WIFI_SETTINGS") }
        val bluetooth = makeButton("Bluetooth Settings") { openSettings("android.settings.BLUETOOTH_SETTINGS") }
        val youtube = makeButton("गीत / भिडियो खोज्नुहोस्") { searchYouTube("") }
        val chat = makeButton("AI Chat खोल्नुहोस्") { openWeb("https://chatgpt.com") }
        val number = EditText(this).apply {
            hint = "फोन नम्बर लेख्नुहोस्"
            setHintTextColor(0xFF9AAFC2.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            inputType = 3
        }
        val call = makeButton("Dialer खोल्नुहोस्") {
            val value = number.text.toString().trim()
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$value"))
            safeStart(intent)
        }
        root.addView(title, matchWrap())
        root.addView(status, matchWrap())
        listOf(listen, camera, wifi, bluetooth, youtube, chat).forEach { root.addView(it, matchWrap()) }
        root.addView(number, matchWrap())
        root.addView(call, matchWrap())
        setContentView(root)
    }

    private fun matchWrap(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 12 }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        setOnClickListener { action() }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ne-NP")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS लाई आदेश दिनुहोस्")
        }
        try { startActivityForResult(intent, requestSpeech) }
        catch (_: Exception) { say("तपाईंको फोनमा Speech Recognition उपलब्ध छैन।") }
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            status.text = "तिमीले भन्यौ: $words"
            handleCommand(words)
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.ROOT)
        when {
            command.contains("camera") || command.contains("क्यामेरा") || command.contains("फोटो") -> openCamera()
            command.contains("youtube") || command.contains("युट्युब") -> openWeb("https://www.youtube.com")
            command.contains("wifi") || command.contains("वाईफाई") -> openSettings("android.settings.WIFI_SETTINGS")
            command.contains("bluetooth") || command.contains("ब्लुटुथ") -> openSettings("android.settings.BLUETOOTH_SETTINGS")
            command.contains("गीत") || command.contains("गाना") || command.contains("भिडियो") -> searchYouTube(raw)
            command.contains("कल") || command.contains("फोन") || command.contains("call") -> safeStart(Intent(Intent.ACTION_DIAL))
            command.contains("समय") || command.contains("time") -> say("अहिलेको समय ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())} हो।")
            else -> say("यो आदेश अझै सिकेको छैन।")
        }
    }

    private fun openCamera() {
        val intent = Intent("android.media.action.IMAGE_CAPTURE")
        safeStart(intent)
    }

    private fun openSettings(action: String) = safeStart(Intent(action))
    private fun searchYouTube(query: String) = openWeb("https://www.youtube.com/results?search_query=${Uri.encode(query.ifBlank { "popular songs" })}")
    private fun openWeb(url: String) = safeStart(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun safeStart(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "यो सुविधा उपलब्ध छैन।", Toast.LENGTH_SHORT).show() }
    }

    private fun say(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("ne", "NP")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestAudio && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListening()
        else if (requestCode == requestAudio) Toast.makeText(this, "Voice का लागि Microphone अनुमति चाहिन्छ।", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
