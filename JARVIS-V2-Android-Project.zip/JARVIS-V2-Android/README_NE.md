# JARVIS V2 Android Starter

यो Android Studio/Gradle project हो, तयार APK होइन। GitHub Actions बाट APK build गर्न सकिन्छ।

## सुविधा
- Speech recognition बाट साधारण आदेश (फोनको speech service र भाषा समर्थनमा निर्भर)
- नेपाली Text-to-Speech (फोनमा Nepali voice उपलब्ध भएमा)
- Camera app खोल्ने
- Dialer खोल्ने; कल गर्नुअघि प्रयोगकर्ताले आफैँ Call थिच्नुपर्छ
- YouTube मा गीत/भिडियो खोज्ने
- Wi-Fi/Bluetooth settings खोल्ने
- ChatGPT website shortcut

## सीमा
- Speech-to-text र नेपाली आवाज फोन/नेटवर्क/स्थापित language pack मा निर्भर हुन्छन्; पूर्ण offline speech सुनिश्चित छैन।
- AI Chat वेबसाइट shortcut हो, app भित्रको embedded AI backend होइन।
- Android ले सुरक्षा कारणले Wi-Fi/Bluetooth toggle जस्ता setting स्वतः परिवर्तन गर्न दिँदैन।
